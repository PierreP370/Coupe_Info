<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="coupleInfo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coupe Info Median</title>
</head>
<body>
    <div>
        <?php include 'header.php'
    ?>
    </div>
    
    <section class="banner" id="banner">
        <h1>Liste des Equipes</h1>
        
    <?php
        // tableau des equipes
        $equipes=[
            "Brésil",
            "Argentine",
            "France",
            "Italie",
            "Espagne",
            "Allemagne",
            "Portugal",
            "Haïti"
        ];

        // affichage tableau des equipes
        
        $roundA=rand(0,1);
        $roundB=rand(0,1);

        $roundC=rand(2,3);
        $roundD=rand(2,3);

        $roundE=rand(4,5);
        $roundF=rand(4,5);

        $roundG=rand(6,7);
        $roundH=rand(6,7);

        // condition pour tirage

        while($roundA==$roundB){
            $roundB=rand(0,1);
        }
        while($roundC==$roundD){
            $roundD=rand(2,3);
        }
        while($roundE==$roundF){
            $roundF=rand(4,5);
        }
        while($roundG==$roundH){
            $roundG=rand(6,7);
        }
    ?>
    <div class="lotserie">
        <table   width="800" height="300" >
        <thead>
            <th>Lot #1 <br/>(1e tête de série)</th>
            <th>Lot #2 <br/>(2e tête de série)</th>
            <th>Lot #3 <br/>(3e tête de série)</th>
            <th>Lot #4 <br/>(4e tête de série)</th>
        </thead>
        <tr id='test'>
            <?php for($i=0;$i<8;$i++)  {
            if($i%2==0){?>
            <td>
              <?php echo $equipes[$i]; ?>
            </td>
            <?php } } ?>
        </tr>
        <tr>
            <?php for($i=0;$i<8;$i++)  {
            if($i%2==1){?>
            <td>
                <?php echo $equipes[$i]; ?>
            </td>
            <?php } } ?>
        </tr>
       </table>
       <div class="boutontirage">
        <form action="index.php" method="post">
        <button class="btn" type="submit" name="tirage" value="Tirage" onclick="alerter(1)">Tirage</button>
        </form>
    </div>
    </div>

    
    
    <!-- <?php 
        if(isset($_POST['tirage'])){
    ?> -->

    
    
    <section class="tirage" id="tirage">
    <div class="tablegroupe">
    <table classe="tiregegroupe"  width="800" height="300">
        <thead>
            <th></th>
            <th>Groupe A</th>
            <th>Groupe B</th>
        </thead>
        <tbody>
            <tr>
                <td>1e tête de série</td>
                <td><?php echo $equipes[$roundA]; ?></td>
                <?php $_SESSION['equipeA1']=$equipes[$roundA];?>
                <td><?php echo $equipes[$roundB]; ?></td>
                <?php $_SESSION['equipeB1']=$equipes[$roundB]; ?>
            </tr>
            <tr>
                <td>2e tête de série</td>
                <td><?php echo $equipes[$roundC]; ?></td>
                <?php $_SESSION['equipeA2']=$equipes[$roundC];?>
                <td><?php echo $equipes[$roundD]; ?></td>
                <?php $_SESSION['equipeB2']=$equipes[$roundD] ?>
            </tr>
            <tr>
                <td>3e tête de série</td>
                <td><?php echo $equipes[$roundE]; ?></td>
                <?php $_SESSION['equipeA3']=$equipes[$roundE];?>
                <td><?php echo $equipes[$roundF]; ?></td>
                <?php $_SESSION['equipeB3']=$equipes[$roundF]; ?>
            </tr>
            <tr>
                <td>4e tête de série</td>
                <td><?php echo $equipes[$roundG]; ?></td>
                <?php $_SESSION['equipeA4']=$equipes[$roundG];?>
                <td><?php echo $equipes[$roundH]; ?></td>
                <?php $_SESSION['equipeB4']=$equipes[$roundH]; ?>
            </tr>
        </tbody>
    </table>
    </div>
    <?php

    $_SESSION['status']=[false,false,false,false,false,false,false,false,false,false,false,false];
    include 'Data/data.php';

    Equipe('equipeA1',$_SESSION['equipeA1']);
    Equipe('equipeA2',$_SESSION['equipeA2']);
    Equipe('equipeA3',$_SESSION['equipeA3']);
    Equipe('equipeA4',$_SESSION['equipeA4']);

    Equipe('equipeB1',$_SESSION['equipeB1']);
    Equipe('equipeB2',$_SESSION['equipeB2']);
    Equipe('equipeB3',$_SESSION['equipeB3']);
    Equipe('equipeB4',$_SESSION['equipeB4']);

    demiFinale();

    petiteFinale();
    grandeFinale();
        }
    ?>
      </section>
    </section>
    <script type="text/javascript">
        window.addEventListener('scroll', function(){
            const header= document.querySelector('header');
            header.classList.toggle("sticky",window.scrollY > 0);
        });
    </script>

</body>
</html>