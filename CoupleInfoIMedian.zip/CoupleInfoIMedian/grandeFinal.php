<?php

session_start();
include 'traitementConfrontation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css" />
    <title>Document</title>
</head>
<body>
  <div><?php include 'header.php'?></div>
    
    <section class="grandefinale">
    <table width="800" height="300">
    <tr>
    <th>Demi-Finale</th>
    <th>Affiche</th>
    <th>Score</th>
    </tr>
    <tr>
    <td>Match 16</td>
    <td><?=$_SESSION['equipe1gf'] ." VS ". $_SESSION['equipe2gf']?></td>
    <td>
    <form action="" method="post">
    <input type="number" name="gfM1Score1" <?php if ($_SESSION['gfM1Etat'] || isset($_POST['submit16'])) { ?> value=<?php echo  $_SESSION['gfM1Score1']?> <?php }  if (
                                 $_SESSION['gfM1Etat'] ||  isset($_POST['submit16'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > :

                              <input type="number" name="gfM1Score2" <?php if ($_SESSION['gfM1Etat']  || isset($_POST['submit16'])) { ?> value=<?php echo  $_SESSION['gfM1Score2'] ?> <?php } if (
                                 $_SESSION['gfM1Etat'] ||  isset($_POST['submit16'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit16" <?php if ($_SESSION['gfM1Etat'] || isset($_POST['submit16'])) { ?> style="display:none" <?php } ?>>
                        </form>
    </td>
    </tr>
    </table>
    <div class="verdique">
    <?php 
    if ($_SESSION['gfM1Etat']) {
       if ($_SESSION['gfM1Score1'] > $_SESSION['gfM1Score2']) {
        $_SESSION['championgf'] =$_SESSION['equipe1gf'];
        $_SESSION['2eplacegf'] =$_SESSION['equipe2gf'];
       }
       elseif ($_SESSION['gfM1Score1']< $_SESSION['gfM1Score2']) 
       {
        $_SESSION['championgf'] =$_SESSION['equipe2gf'];
        $_SESSION['2eplacegf'] =$_SESSION['equipe1gf'];
       }
       else {
          $champion=rand(0,1);

          if ($champion==0) {
            $_SESSION['championgf'] =$_SESSION['equipe1gf'];
            $_SESSION['2eplacegf'] =$_SESSION['equipe2gf'];
          }
          else {
            $_SESSION['championgf'] =$_SESSION['equipe2gf'];
            $_SESSION['2eplacegf'] =$_SESSION['equipe1gf'];
          }
       }

       echo  "<br>".$_SESSION['championgf']." remporte le titre du championnat coupe 3e info <br>";
       echo   "<br>".$_SESSION['2eplacegf']." 2e Place <br>";
    }
    
    ?></div>
    </section>
</body>
</html>