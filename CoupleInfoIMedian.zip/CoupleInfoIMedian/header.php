<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="coupleInfo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coupe Info</title>
</head>
<body>
<header>
        <a href="#" class="logo">COUPE <span>info</span> MEDIAN</a>
        <ul class="navigation">
            <li><a href="#banner">Equipes</a></li>
            <li><a href="#tirage">Tirage</a></li>
            <li><a href="rencontre.php">Confrontation</a></li>
            <li><a href="classement.php">Classement</a></li>
            <li><a href="demieFinal.php">Demie-Finale</a></li>
            <li><a href="petiteFinale.php">Petite-Finale</a></li>
            <li><a href="grandeFinal.php">Grande-Finale</a></li>
        </ul>
    </header>
</body>
</html>