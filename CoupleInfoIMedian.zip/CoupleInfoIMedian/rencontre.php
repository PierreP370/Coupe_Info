<?php
    session_start();
    include 'traitementConfrontation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="coupleinfo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
     <?php
       include 'header.php'
      ?>
      <section class="rencontre">
      <div class="confrontationgroup">
    <h1>Confrontation Groupe A</h1>
      <table class="rencontre" width="800" height="300">
        <thead>
            <th>Groupe A</th>
            <th>Affichage</th> 
            <th>Score</th>
        </thead>
        <tbody>
            <tr>
            <td>Match 1</td>
                  <td><?php echo $_SESSION['equipeA1']['nom'] . " VS " . $_SESSION['equipeA2']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m1sceqA1" 
                              <?php 
                                if (
                                    $_SESSION['status'][0] || isset($_POST['submit1'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA1']['score'][0] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][0] ||  isset($_POST['submit1'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m1sceqA2" <?php if ($_SESSION['status'][0] || isset($_POST['submit1'])) { ?> value=<?php echo  $_SESSION['equipeA2']['score'][0] ?> <?php } if (
                                $_SESSION['status'][0] ||  isset($_POST['submit1'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit1" <?php if ($_SESSION['status'][0] || isset($_POST['submit1'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 2</td>
                  <td><?php echo $_SESSION['equipeA3']['nom'] . " VS " . $_SESSION['equipeA4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                        <input type="number" name="m2sceqA3" 
                              <?php 
                                if (
                                    $_SESSION['status'][1] || isset($_POST['submit2'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA3']['score'][0] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][1] ||  isset($_POST['submit2'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m2sceqA4" <?php if ($_SESSION['status'][1] || isset($_POST['submit2'])) { ?> value=<?php echo  $_SESSION['equipeA4']['score'][0] ?> <?php } if (
                                $_SESSION['status'][1] ||  isset($_POST['submit2'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >
                              <input type="submit" value="valider" name="submit2" <?php if ($_SESSION['status'][1] || isset($_POST['submit2'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <td>Match 3</td>
                  <td><?php echo $_SESSION['equipeA1']['nom'] . " VS " . $_SESSION['equipeA3']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                        <input type="number" name="m3sceqA1" 
                              <?php 
                                if (
                                    $_SESSION['status'][2] || isset($_POST['submit3'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA1']['score'][1] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][2] ||  isset($_POST['submit3'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m3sceqA3" <?php if ($_SESSION['status'][2] || isset($_POST['submit3'])) { ?> value=<?php echo  $_SESSION['equipeA3']['score'][1] ?> <?php } if (
                                $_SESSION['status'][2] ||  isset($_POST['submit3'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >
                              <input type="submit" value="valider" name="submit3" <?php if ($_SESSION['status'][2] || isset($_POST['submit3'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            
            <td>Match 4</td>
                  <td><?php echo $_SESSION['equipeA2']['nom'] . " VS " . $_SESSION['equipeA4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                        <input type="number" name="m4sceqA2" 
                              <?php 
                                if (
                                    $_SESSION['status'][3] || isset($_POST['submit4'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA2']['score'][1] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][3] ||  isset($_POST['submit4'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m4sceqA4" <?php if ($_SESSION['status'][3] || isset($_POST['submit4'])) { ?> value=<?php echo  $_SESSION['equipeA4']['score'][1] ?> <?php } if (
                                $_SESSION['status'][3] ||  isset($_POST['submit4'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >
                              <input type="submit" value="valider" name="submit4" <?php if ($_SESSION['status'][3] || isset($_POST['submit4'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <td>Match 5</td>
                  <td><?php echo $_SESSION['equipeA1']['nom'] . " VS " . $_SESSION['equipeA4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                        <input type="number" name="m5sceqA1" 
                              <?php 
                                if (
                                    $_SESSION['status'][4] || isset($_POST['submit5'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA1']['score'][2] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][4] ||  isset($_POST['submit5'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m5sceqA4" <?php if ($_SESSION['status'][4] || isset($_POST['submit5'])) { ?> value=<?php echo  $_SESSION['equipeA4']['score'][2] ?> <?php } if (
                                $_SESSION['status'][4] ||  isset($_POST['submit5'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >
                              <input type="submit" value="valider" name="submit5" <?php if ($_SESSION['status'][4] || isset($_POST['submit5'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <td>Match 6</td>
                  <td><?php echo $_SESSION['equipeA2']['nom'] . " VS " . $_SESSION['equipeA3']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                        <input type="number" name="m6sceqA2" 
                              <?php 
                                if (
                                    $_SESSION['status'][5] || isset($_POST['submit6'])) { ?> 
                                    value=<?php echo $_SESSION['equipeA2']['score'][2] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][5] ||  isset($_POST['submit6'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m6sceqA3" <?php if ($_SESSION['status'][5] || isset($_POST['submit6'])) { ?> value=<?php echo  $_SESSION['equipeA3']['score'][2] ?> <?php } if (
                                $_SESSION['status'][5] ||  isset($_POST['submit6'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >
                              <input type="submit" value="valider" name="submit6" <?php if ($_SESSION['status'][5] || isset($_POST['submit6'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
        </tbody>
      </table>
      <h1>Confrontation Groupe B</h1>
      <table class="rencontreb" width="800" height="300">
        <thead>
            <th>Groupe B</th>
            <th>Affichage</th> 
            <th>Score</th>
        </thead>
        <tbody>
            <tr>
            <td>Match 7</td>
                  <td><?php echo $_SESSION['equipeB1']['nom'] . " VS " . $_SESSION['equipeB2']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m1sceqB1" 
                              <?php 
                                if (
                                    $_SESSION['status'][6] || isset($_POST['submit7'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB1']['score'][0] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][6] ||  isset($_POST['submit7'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m1sceqB2" <?php if ($_SESSION['status'][6] || isset($_POST['submit7'])) { ?> value=<?php echo  $_SESSION['equipeB2']['score'][0] ?> <?php } if (
                                $_SESSION['status'][6] ||  isset($_POST['submit7'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit7" <?php if ($_SESSION['status'][6] || isset($_POST['submit7'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 8</td>
                  <td><?php echo $_SESSION['equipeB3']['nom'] . " VS " . $_SESSION['equipeB4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m2sceqB3" 
                              <?php 
                                if (
                                    $_SESSION['status'][7] || isset($_POST['submit8'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB3']['score'][0] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][7] ||  isset($_POST['submit8'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m2sceqB4" <?php if ($_SESSION['status'][7] || isset($_POST['submit8'])) { ?> value=<?php echo  $_SESSION['equipeB4']['score'][0] ?> <?php } if (
                                $_SESSION['status'][7] ||  isset($_POST['submit8'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit8" <?php if ($_SESSION['status'][7] || isset($_POST['submit8'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 9</td>
                  <td><?php echo $_SESSION['equipeB1']['nom'] . " VS " . $_SESSION['equipeB3']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m3sceqB1" 
                              <?php 
                                if (
                                    $_SESSION['status'][8] || isset($_POST['submit9'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB1']['score'][1] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][8] ||  isset($_POST['submit9'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m3sceqB3" <?php if ($_SESSION['status'][8] || isset($_POST['submit9'])) { ?> value=<?php echo  $_SESSION['equipeB3']['score'][1] ?> <?php } if (
                                $_SESSION['status'][8] ||  isset($_POST['submit9'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit9" <?php if ($_SESSION['status'][8] || isset($_POST['submit9'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 10</td>
                  <td><?php echo $_SESSION['equipeB2']['nom'] . " VS " . $_SESSION['equipeB4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m4sceqB2" 
                              <?php 
                                if (
                                    $_SESSION['status'][9] || isset($_POST['submit10'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB1']['score'][1] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][9] ||  isset($_POST['submit10'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m4sceqB4" <?php if ($_SESSION['status'][9] || isset($_POST['submit10'])) { ?> value=<?php echo  $_SESSION['equipeB4']['score'][1] ?> <?php } if (
                                $_SESSION['status'][9] ||  isset($_POST['submit10'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit10" <?php if ($_SESSION['status'][9] || isset($_POST['submit10'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 11</td>
                  <td><?php echo $_SESSION['equipeB1']['nom'] . " VS " . $_SESSION['equipeB4']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m5sceqB1" 
                              <?php 
                                if (
                                    $_SESSION['status'][10] || isset($_POST['submit11'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB1']['score'][2] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][10] ||  isset($_POST['submit11'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m5sceqB4" <?php if ($_SESSION['status'][10] || isset($_POST['submit11'])) { ?> value=<?php echo  $_SESSION['equipeB4']['score'][1] ?> <?php } if (
                                $_SESSION['status'][10] ||  isset($_POST['submit11'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit11" <?php if ($_SESSION['status'][10] || isset($_POST['submit11'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            <tr>
            <td>Match 12</td>
                  <td><?php echo $_SESSION['equipeB2']['nom'] . " VS " . $_SESSION['equipeB3']['nom'] ?></td>
                  <td class="score">
                        <form action="" method="post">
                              <input type="number" name="m6sceqB2" 
                              <?php 
                                if (
                                    $_SESSION['status'][11] || isset($_POST['submit12'])) { ?> 
                                    value=<?php echo $_SESSION['equipeB2']['score'][2] ?> <?php 
                                }
                                if (
                                   $_SESSION['status'][11] ||  isset($_POST['submit12'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > -

                              <input type="number" name="m6sceqB3" <?php if ($_SESSION['status'][11] || isset($_POST['submit12'])) { ?> value=<?php echo  $_SESSION['equipeB3']['score'][2] ?> <?php } if (
                                $_SESSION['status'][11] ||  isset($_POST['submit12'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit12" <?php if ($_SESSION['status'][11] || isset($_POST['submit12'])) { ?> style="display:none" <?php } ?>>
                        </form>
                  </td>
            </tr>
            
        </tbody>
      </table>
      </div>
      </section>
   
</body>
</html>