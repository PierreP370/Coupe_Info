<?php
session_start();
include 'traitementConfrontation.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="coupleInfo.css">
    <title>Demie Finale</title>
</head>

<body>
    <div><?php include 'header.php'?></div>
   
   <section class="dmifinal">
       <div >
    <table width="800" height="300">
        <tr>
            <th>Demi-Finale</th>
            <th>Affiche</th>
            <th>Score</th>
        </tr>
        <tr>
            <td>Match 13</td>
            <td><?= $_SESSION['groupeA'][0]['nom'] . " VS " . $_SESSION['groupeB'][1]['nom'] ?></td>
            <td>
                <form action="" method="post">
                    <input type="number" name="dfM1Score1" <?php if ($_SESSION['dfM1Etat'] || isset($_POST['submit13'])) { ?> value=<?php echo  $_SESSION['dfM1Score1'] ?> <?php }
                                                                                                                                                                        if (
                                                                                                                                                                            $_SESSION['dfM1Etat'] ||  isset($_POST['submit13'])
                                                                                                                                                                        ) { ?> disabled="disabled" <?php } ?> min="0">

                    <input type="number" name="dfM1Score2" <?php if ($_SESSION['dfM1Etat'] || isset($_POST['submit13'])) { ?> value=<?php echo  $_SESSION['dfM1Score2'] ?> <?php }
                                                                                                                                                                        if (
                                                                                                                                                                            $_SESSION['dfM1Etat'] ||  isset($_POST['submit13'])
                                                                                                                                                                        ) { ?> disabled="disabled" <?php } ?> min="0">

                    <input type="submit" value="valider" name="submit13" <?php if ($_SESSION['dfM1Etat'] || isset($_POST['submit13'])) { ?> style="display:none" <?php } ?>>
                </form>
            </td>
        </tr>



        <tr>
            <td>Match 14</td>
            <td><?= $_SESSION['groupeB'][0]['nom'] . " VS " . $_SESSION['groupeA'][1]['nom'] ?></td>
            <td>
                <form action="" method="post">
                    <input type="number" name="dfM2Score1" <?php if ($_SESSION['dfM2Etat'] || isset($_POST['submit14'])) { ?> value=<?php echo  $_SESSION['dfM2Score1'] ?> <?php }
                                                                                                                                                                        if ($_SESSION['dfM2Etat'] ||  isset($_POST['submit14'])) { ?> disabled="disabled" <?php } ?> min="0">
                    <input type="number" name="dfM2Score2" <?php if ($_SESSION['dfM2Etat'] || isset($_POST['submit14'])) { ?> value=<?php echo  $_SESSION['dfM2Score2'] ?> <?php }
                                                                                                                                                                        if ($_SESSION['dfM2Etat'] ||  isset($_POST['submit14'])) { ?> disabled="disabled" <?php } ?> min="0">

                    <input type="submit" value="valider" name="submit14" <?php if ($_SESSION['dfM2Etat'] || isset($_POST['submit14'])) { ?> style="display:none" <?php } ?>>
                </form>
            </td>
        </tr>
    </table>

    <?php

    // ============================= gestion qualifiant pour match 1 ======================
    if ($_SESSION['dfM1Etat'] && $_SESSION['dfM2Etat']) {
        if ($_SESSION['dfM1Score1'] > $_SESSION['dfM1Score2']) {

            $_SESSION['equipe1gf'] = $_SESSION['groupeA'][0]['nom'];
            $_SESSION['equipe1pf'] = $_SESSION['groupeB'][1]['nom'];
        } elseif ($_SESSION['dfM1Score1'] < $_SESSION['dfM1Score2']) {
            $_SESSION['equipe1pf'] = $_SESSION['groupeA'][0]['nom'];
            $_SESSION['equipe1gf'] = $_SESSION['groupeB'][1]['nom'];
        }
            // ============================= gestion penalite directpour match 1 ======================
        else {
            $qualifiant=rand(0,1);
  
            if ($qualifiant==0) {
                $_SESSION['equipe1gf'] = $_SESSION['groupeA'][0]['nom'];
                $_SESSION['equipe1pf'] = $_SESSION['groupeB'][1]['nom'];
            }
            else {
                $_SESSION['equipe1pf'] = $_SESSION['groupeA'][0]['nom'];
                $_SESSION['equipe1gf'] = $_SESSION['groupeB'][1]['nom'];
            }
         }


    // ============================= gestion qualifiant pour match 2 ======================
        if ($_SESSION['dfM2Score1'] > $_SESSION['dfM2Score2']) {
            $_SESSION['equipe2gf'] = $_SESSION['groupeB'][0]['nom'];

            $_SESSION['equipe2pf'] = $_SESSION['groupeA'][1]['nom'];
        } elseif ($_SESSION['dfM1Score1'] < $_SESSION['dfM1Score2']) {
            $_SESSION['equipe2gf'] = $_SESSION['groupeA'][1]['nom'];

            $_SESSION['equipe2pf'] = $_SESSION['groupeB'][0]['nom'];
        }
          // ============================= gestion penalite directpour match 2 ======================
        else {
            $qualifiant=rand(0,1);
  
            if ($qualifiant==0) {
                $_SESSION['equipe2gf'] = $_SESSION['groupeB'][0]['nom'];

                $_SESSION['equipe2pf'] = $_SESSION['groupeA'][1]['nom'];
            }
            else {
                $_SESSION['equipe2gf'] = $_SESSION['groupeA'][1]['nom'];

                $_SESSION['equipe2pf'] = $_SESSION['groupeB'][0]['nom'];
            }
         }
    }
    ?>
    </div>
    </section>
</body>

</html>