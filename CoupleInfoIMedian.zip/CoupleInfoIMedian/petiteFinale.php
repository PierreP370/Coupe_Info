
<?php

session_start();
include 'traitementConfrontation.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css" />
    <title>Petite Finale</title>
</head>
<body>
  <div><?php include 'header.php'?></div>
  
  <section class="petitefinale">
    <table width="800" height="300">
    <tr>
    <th>Demi-Finale</th>
    <th>Affiche</th>
    <th>Score</th>
    </tr>
    <tr>
    <td>Match 15</td>
    <td><?=$_SESSION['equipe1pf']." VS ".$_SESSION['equipe2pf']?></td>
    <td>
    <form action="" method="post">
                              <input type="number" name="pfM1Score1" <?php if ($_SESSION['pfM1Etat'] || isset($_POST['submit15'])) { ?> value=<?php echo  $_SESSION['pfM1Score1']?> <?php }  if (
                                 $_SESSION['pfM1Etat'] ||  isset($_POST['submit15'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" > :

                              <input type="number" name="pfM1Score2" <?php if ($_SESSION['pfM1Etat']  || isset($_POST['submit15'])) { ?> value=<?php echo  $_SESSION['pfM1Score2'] ?> <?php } if (
                                 $_SESSION['pfM1Etat'] ||  isset($_POST['submit15'])
                               ) { ?> 
                              disabled="disabled" <?php } ?>  min="0" >

                              <input type="submit" value="valider" name="submit15" <?php if ($_SESSION['pfM1Etat'] || isset($_POST['submit15'])) { ?> style="display:none" <?php } ?>>
                        </form>
    </td>
    </tr>
    </table>
<div class="verdique">
    <?php 
    if ($_SESSION['pfM1Etat']) {
       if ($_SESSION['pfM1Score1']> $_SESSION['pfM1Score2']) {
        $_SESSION['championpf'] =$_SESSION['equipe1pf'];
        $_SESSION['2eplacepf'] =$_SESSION['equipe2pf'];
       }
       elseif ($_SESSION['pfM1Score1']< $_SESSION['pfM1Score2']) 
       {
        $_SESSION['championpf'] =$_SESSION['equipe2pf'];
        $_SESSION['2eplacepf'] =$_SESSION['equipe1pf'];
       }
       else {
          $champion=rand(0,1);

          if ($champion==0) {
            $_SESSION['championpf'] =$_SESSION['equipe1pf'];
            $_SESSION['2eplacepf'] =$_SESSION['equipe2pf'];
          }
          else {
            $_SESSION['championpf'] =$_SESSION['equipe2pf'];
            $_SESSION['2eplacepf'] =$_SESSION['equipe1pf'];
          }
       }

       echo  "<br>".$_SESSION['championpf']." termine en 3e position <br>";
       echo   "<br>".$_SESSION['2eplacepf']." termine en 4e position <br>";
    }
    
    ?>
    </div>
    </section>
</body>
</html>
