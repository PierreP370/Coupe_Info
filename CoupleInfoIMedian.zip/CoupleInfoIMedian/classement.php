<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="coupleInfo.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classement</title>
</head>
<body>

<?php
include 'header.php'
?>
<section class="classement">
<?php
session_start();
include 'GroupeA.php';
include 'GroupeB.php';
?>
    <table class="classementgroupa" width="800" height="300">
        <tr>
            <th colspan="9">GROUPE A</th>
        </tr>
        <tr>
            <th></th>
            <th>MJ</th>
            <th>MG</th>
            <th>MN</th>
            <th>MP</th>
            <th>BP</th>
            <th>BC</th>
            <th>Dif</th>
            <th>Point</th>
        </tr>
       <?= ordonnerA(); ?>
</table>

<table class="classementgroupa" width="800" height="300">
        <tr>
            <th colspan="9">GROUPE B</th>
        </tr>
        <tr>
            <th></th>
            <th>MJ</th>
            <th>MG</th>
            <th>MN</th>
            <th>MP</th>
            <th>BP</th>
            <th>BC</th>
            <th>Dif</th>
            <th>Point</th>
        </tr>
        <?=ordonnerB()?>
</table>
</section>
</body>
</html>