<?php

    include 'classementMng.php';
    
    if(isset($_POST['submit1'])){
        $_SESSION['equipeA1']['score'][0]=$_POST['m1sceqA1'];
        $_SESSION['equipeA2']['score'][0]=$_POST['m1sceqA2'];
        $_SESSION['status'][0]=true;
        traitementClassement('equipeA1','equipeA2',0);
    }
    if(isset($_POST['submit2'])){
        $_SESSION['equipeA3']['score'][0]=$_POST['m2sceqA3'];
        $_SESSION['equipeA4']['score'][0]=$_POST['m2sceqA4'];
        $_SESSION['status'][1]=true;
        traitementClassement('equipeA3','equipeA4',0);
    }
    if(isset($_POST['submit3'])){
        $_SESSION['equipeA1']['score'][1]=$_POST['m3sceqA1'];
        $_SESSION['equipeA3']['score'][1]=$_POST['m3sceqA3'];
        $_SESSION['status'][2]=true;
        traitementClassement('equipeA1','equipeA3',1);
    }
    if(isset($_POST['submit4'])){
        $_SESSION['equipeA2']['score'][1]=$_POST['m4sceqA2'];
        $_SESSION['equipeA4']['score'][1]=$_POST['m4sceqA4'];
        $_SESSION['status'][3]=true;
        traitementClassement('equipeA2','equipeA4',1);
    }
    if(isset($_POST['submit5'])){
        $_SESSION['equipeA1']['score'][2]=$_POST['m5sceqA1'];
        $_SESSION['equipeA4']['score'][2]=$_POST['m5sceqA4'];
        $_SESSION['status'][4]=true;
        traitementClassement('equipeA1','equipeA4',2);
    }
    if(isset($_POST['submit6'])){
        $_SESSION['equipeA2']['score'][2]=$_POST['m6sceqA2'];
        $_SESSION['equipeA3']['score'][2]=$_POST['m6sceqA3'];
        $_SESSION['status'][5]=true;
        traitementClassement('equipeA2','equipeA3',2);
    }
    if(isset($_POST['submit7'])){
        $_SESSION['equipeB1']['score'][0]=$_POST['m1sceqB1'];
        $_SESSION['equipeB2']['score'][0]=$_POST['m1sceqB2'];
        $_SESSION['status'][6]=true;
        traitementClassement('equipeB1','equipeB2',0);
    }
    if(isset($_POST['submit8'])){
        $_SESSION['equipeB3']['score'][0]=$_POST['m2sceqB3'];
        $_SESSION['equipeB4']['score'][0]=$_POST['m2sceqB4'];
        $_SESSION['status'][7]=true;
        traitementClassement('equipeB3','equipeB4',0);
    }
    if(isset($_POST['submit9'])){
        $_SESSION['equipeB1']['score'][1]=$_POST['m3sceqB1'];
        $_SESSION['equipeB3']['score'][1]=$_POST['m3sceqB3'];
        $_SESSION['status'][8]=true;
        traitementClassement('equipeB1','equipeB3',1);
    }
    if(isset($_POST['submit10'])){
        $_SESSION['equipeB2']['score'][1]=$_POST['m4sceqB2'];
        $_SESSION['equipeB4']['score'][1]=$_POST['m4sceqB4'];
        $_SESSION['status'][9]=true;
        traitementClassement('equipeB2','equipeB4',1);
    }
    if(isset($_POST['submit11'])){
        $_SESSION['equipeB1']['score'][2]=$_POST['m5sceqB1'];
        $_SESSION['equipeB4']['score'][2]=$_POST['m5sceqB4'];
        $_SESSION['status'][10]=true;
        traitementClassement('equipeB1','equipeB4',2);
    }
    if(isset($_POST['submit12'])){
        $_SESSION['equipeB2']['score'][2]=$_POST['m6sceqB2'];
        $_SESSION['equipeB3']['score'][2]=$_POST['m6sceqB3'];
        $_SESSION['status'][11]=true;
        traitementClassement('equipeB2','equipeB3',2);
    }
    if (isset($_POST['submit13'])) {
        $_SESSION['dfM1Score1'] = $_POST['dfM1Score1'];
        $_SESSION['dfM1Score2'] = $_POST['dfM1Score2'];
        $_SESSION['dfM1Etat'] = true;
    }
    
    if (isset($_POST['submit14'])) {
        $_SESSION['dfM2Score1'] = $_POST['dfM2Score1'];
        $_SESSION['dfM2Score2'] = $_POST['dfM2Score2'];
        $_SESSION['dfM2Etat'] = true;
    }
    
    if (isset($_POST['submit15'])) {
        $_SESSION['pfM1Score1'] = $_POST['pfM1Score1'];
        $_SESSION['pfM1Score2'] = $_POST['pfM1Score2'];
        $_SESSION['pfM1Etat'] = true;
    }
    if (isset($_POST['submit16'])) {
        $_SESSION['gfM1Score1'] = $_POST['gfM1Score1'];
        $_SESSION['gfM1Score2'] = $_POST['gfM1Score2'];
        $_SESSION['gfM1Etat'] = true;
    }
?>