<?php
function ordonnerB()
{

  $_SESSION['groupeB'] = [
    'equipeB1' =>
    [
      'nom' => $_SESSION['equipeB1']['nom'],
      'MJ' => $_SESSION['equipeB1']['MJ'],
      'MG' => $_SESSION['equipeB1']['MG'],
      'MN' => $_SESSION['equipeB1']['MN'],
      'MP' => $_SESSION['equipeB1']['MP'],
      'BP' => $_SESSION['equipeB1']['BP'],
      'BC' => $_SESSION['equipeB1']['BC'],
      'DIF' => $_SESSION['equipeB1']['DIF'],
      'Pts' => $_SESSION['equipeB1']['Pts']
    ],
    "equipeB2" =>
    [

      'nom' => $_SESSION['equipeB2']['nom'],
      'MJ' => $_SESSION['equipeB2']['MJ'],
      'MG' => $_SESSION['equipeB2']['MG'],
      'MN' => $_SESSION['equipeB2']['MN'],
      'MP' => $_SESSION['equipeB2']['MP'],
      'BP' => $_SESSION['equipeB2']['BP'],
      'BC' => $_SESSION['equipeB2']['BC'],
      'DIF' => $_SESSION['equipeB2']['DIF'],
      'Pts' => $_SESSION['equipeB2']['Pts']
    ],

    "equipeB3" =>
    [
      'nom' => $_SESSION['equipeB3']['nom'],
      'MJ' => $_SESSION['equipeB3']['MJ'],
      'MG' => $_SESSION['equipeB3']['MG'],
      'MN' => $_SESSION['equipeB3']['MN'],
      'MP' => $_SESSION['equipeB3']['MP'],
      'BP' => $_SESSION['equipeB3']['BP'],
      'BC' => $_SESSION['equipeB3']['BC'],
      'DIF' => $_SESSION['equipeB3']['DIF'],
      'Pts' => $_SESSION['equipeB3']['Pts']
    ],
    "equipeB4" =>
    [
      'nom' => $_SESSION['equipeB4']['nom'],
      'MJ' => $_SESSION['equipeB4']['MJ'],
      'MG' => $_SESSION['equipeB4']['MG'],
      'MN' => $_SESSION['equipeB4']['MN'],
      'MP' => $_SESSION['equipeB4']['MP'],
      'BP' => $_SESSION['equipeB4']['BP'],
      'BC' => $_SESSION['equipeB4']['BC'],
      'DIF' => $_SESSION['equipeB4']['DIF'],
      'Pts' => $_SESSION['equipeB4']['Pts']
    ]

  ];


  usort($_SESSION['groupeB'], function ($x, $y) {
    return $y["Pts"] - $x["Pts"];
  });


  foreach ($_SESSION['groupeB'] as $key => $value) {
    echo  "<tr>";
    foreach ($value as $key => $value) {
      echo "<td>" . $value . "</td>";
    }
    echo "<tr>";
  }
}
