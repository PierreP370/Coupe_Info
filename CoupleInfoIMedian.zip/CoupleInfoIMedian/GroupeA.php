<?php
function ordonnerA()
{

  $_SESSION['groupeA'] = [
    'equipeA1' =>
    [
      'nom' => $_SESSION['equipeA1']['nom'],
      'MJ' => $_SESSION['equipeA1']['MJ'],
      'MG' => $_SESSION['equipeA1']['MG'],
      'MN' => $_SESSION['equipeA1']['MN'],
      'MP' => $_SESSION['equipeA1']['MP'],
      'BP' => $_SESSION['equipeA1']['BP'],
      'BC' => $_SESSION['equipeA1']['BC'],
      'DIF' => $_SESSION['equipeA1']['DIF'],
      'Pts' => $_SESSION['equipeA1']['Pts']
    ],
    "equipeA2" =>
    [

      'nom' => $_SESSION['equipeA2']['nom'],
      'MJ' => $_SESSION['equipeA2']['MJ'],
      'MG' => $_SESSION['equipeA2']['MG'],
      'MN' => $_SESSION['equipeA2']['MN'],
      'MP' => $_SESSION['equipeA2']['MP'],
      'BP' => $_SESSION['equipeA2']['BP'],
      'BC' => $_SESSION['equipeA2']['BC'],
      'DIF' => $_SESSION['equipeA2']['DIF'],
      'Pts' => $_SESSION['equipeA2']['Pts']
    ],
    "equipeA3" =>
    [
      'nom' => $_SESSION['equipeA3']['nom'],
      'MJ' => $_SESSION['equipeA3']['MJ'],
      'MG' => $_SESSION['equipeA3']['MG'],
      'MN' => $_SESSION['equipeA3']['MN'],
      'MP' => $_SESSION['equipeA3']['MP'],
      'BP' => $_SESSION['equipeA3']['BP'],
      'BC' => $_SESSION['equipeA3']['BC'],
      'DIF' => $_SESSION['equipeA3']['DIF'],
      'Pts' => $_SESSION['equipeA3']['Pts']
    ],
    "equipeA4" =>
    [
      'nom' => $_SESSION['equipeA4']['nom'],
      'MJ' => $_SESSION['equipeA4']['MJ'],
      'MG' => $_SESSION['equipeA4']['MG'],
      'MN' => $_SESSION['equipeA4']['MN'],
      'MP' => $_SESSION['equipeA4']['MP'],
      'BP' => $_SESSION['equipeA4']['BP'],
      'BC' => $_SESSION['equipeA4']['BC'],
      'DIF' => $_SESSION['equipeA4']['DIF'],
      'Pts' => $_SESSION['equipeA4']['Pts']
    ]

  ];


  usort($_SESSION['groupeA'], function ($x, $y) {
    return $y["Pts"] - $x["Pts"];
  });


  foreach ($_SESSION['groupeA'] as $key => $value) {
    echo  "<tr>";
    foreach ($value as $key => $value) {
      echo "<td>" . $value . "</td>";
    }
    echo "<tr>";
  }
}
